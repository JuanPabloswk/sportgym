package com.example.sportgym.Service;


import com.example.sportgym.Model.Suscripcion;

import java.util.List;

public interface SuscripcionService {
     List<Suscripcion> listarSuscripcion();
}
