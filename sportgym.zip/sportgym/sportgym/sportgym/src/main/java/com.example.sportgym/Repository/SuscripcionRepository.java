package com.example.sportgym.Repository;

import com.example.sportgym.Model.Suscripcion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SuscripcionRepository extends JpaRepository<Suscripcion,Long> {
}
