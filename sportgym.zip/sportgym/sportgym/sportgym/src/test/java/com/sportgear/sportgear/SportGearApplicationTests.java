package com.sportgear.sportgear;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportGearApplicationTests {

	@Test
	void contextLoads() {
	}

}
