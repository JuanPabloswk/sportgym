# sportgym

INFORMACIÓN 

Para poder hacer uso de este programa se necesita lo siguiente en cuenta:

-Se usa el JDK 17 (JAVA)
-Se usa Springboot 2.5.7

*Descargar el zip con los archivos del codigo y abrirlo en IntelliJ IDEA
*Crear una nueva base de datos llamada por ej: sportgymdb
*Para instalarlo simplemente debemos importar lo que es la base de datos en MySql
*En application.properties es necesario colocar nuestro usuario y contraseña para poder conectarla y además del nombre de la base de datos




